import React from 'react';
import { compose, withStateHandlers } from "recompose";
import Geocode from "react-geocode";
import { InfoWindow, withGoogleMap, withScriptjs, GoogleMap, Marker } from 'react-google-maps';
import { GoogleMap_API } from 'store/constant';
const google = window.google;


const Map = compose(
  withStateHandlers((props) => ({
    isMarkerShown: true,
    markerPosition: { lat: props?.latLang?.lat, lng: props?.latLang?.lng }
  }), {
    onMapClick: () => (e, getReverseGeocodingData) => {
      // getReverseGeocodingData(e.latLng);
      console.log('isMarkerShown', getReverseGeocodingData(e.latLng.toString()), e.latLng);
      return ({
        markerPosition: e.latLng,
        isMarkerShown: true
      });
    }
  }),
  withScriptjs,
  withGoogleMap
)
  (props =>
    <GoogleMap
      defaultZoom={16}
      defaultCenter={{ lat: props.latLang?.lat, lng: props.latLang?.lng }}
      onClick={(e) => { props.onMapClick(e, props.getReverseGeocodingData); }}
    >
      {console.log('GoogleMap--', props.latLang)}
      {props.isMarkerShown && <Marker position={props.markerPosition} />}

    </GoogleMap>
  );

export default class MapContainer extends React.Component {
  constructor(props) {
    super(props);
    console.log('props', props);
  }
  getReverseGeocodingData = (latVal, lngVal) => {
    // let langlatData = lat.split('(');

    let newStr = latVal.replace(/[\])}[{(]/g, '');

    let lat = newStr.split(',')[0];
    let lng = newStr.split(',')[1];

    if (!!lat && !!lng) {
      Geocode.setApiKey(GoogleMap_API);
      Geocode.enableDebug();

      Geocode.fromLatLng(lat, lng).then(
        response => {
          const address = response.results[0].formatted_address;
          this.props.setAddress(address);
          this.props.setStoreAddress(address);
          this.props.setLatitude(+lat);
          this.props.setLongitude(+lng);
        },
        error => {
          console.error(error);
        }
      );

      // var latlng = new google.maps.LatLng(newStr.split(',')[0], newStr.split(',')[1]);
      // // This is making the Geocode request
      // var geocoder = new google.maps.Geocoder();
      // geocoder.geocode({ 'latLng': latlng }, (results, status) => {
      //   if (status !== google.maps.GeocoderStatus.OK) {
      //     alert(status);
      //   }
      //   // This is checking to see if the Geoeode Status is OK before proceeding
      //   if (status == google.maps.GeocoderStatus.OK) {
      //     console.log('latLng', results);
      //     var address = (results[0].formatted_address);
      //     this.props.setAddress(address);
      //   }
      // });
    }



  };
  render() {
    return (
      <div style={{ height: '100%' }}>
        <Map
          latLang={this.props.locationLatLang}
          getReverseGeocodingData={this.getReverseGeocodingData}
          googleMapURL="https://maps.googleapis.com/maps/api/js?key=AIzaSyBepTp6ot1oLeiyAXqTlHnQE3mlTeUlFGg"
          loadingElement={<div style={{ height: `100%` }} />}
          containerElement={<div style={{ height: `400px` }} />}
          mapElement={<div style={{ height: `100%` }} />}
        />
      </div>
    );
  }
}



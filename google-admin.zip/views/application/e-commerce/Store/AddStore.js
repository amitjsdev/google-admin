import React, { useEffect, useState } from "react";
import PropTypes from "prop-types";

// material-ui
// import { useTheme } from "@mui/material/styles";

import {
  Button,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  Grid,
  IconButton,
  Stack,
  TextField,
  Tooltip,
} from "@mui/material";
import { LocalizationProvider } from "@mui/lab";
import AdapterDateFns from "@mui/lab/AdapterDateFns";
import API from "../../../../api/axios";
// import uploadIcon from "../../../../assets/images/e-commerce/uploadIcon.svg";

// third-party
import _ from "lodash";
import * as Yup from "yup";
import { useFormik, Form, FormikProvider } from "formik";
import LoadingButton from "@mui/lab/LoadingButton";

// project imports
import { GoogleMap_API, gridSpacing } from "store/constant";
import CloseIcon from "@mui/icons-material/Close";
import { successAlert, apiErrorHandler, errorAlert } from "../../../helpers";
// assets
import DeleteIcon from "@mui/icons-material/Delete";

import {
  withGoogleMap,
  withScriptjs,
  GoogleMap,
  Marker,
  InfoWindow
} from "react-google-maps";
import axios from "axios";

import Map from "./GoogleMap";
import './index.css';
// // constant
const getInitialValues = (event, range) => {
  const newEvent = {
    name: '',
    street_address: '',
    city: '',
    country: '',
    postal_code: '',
    state: '',
    latitude: '',
    longitude: '',
  };

  if (event || range) {
    return _.merge({}, newEvent, event);
  }

  return newEvent;
};

// ==============================|| CALENDAR EVENT ADD / EDIT / DELETE ||============================== //

const AddStore = ({
  event,
  range,
  handleDelete,
  onCancel,
  handleCloseModal,
  reloadApi,
  editStoreData,
  personalData
}) => {
  // const theme = useTheme();
  const isCreating = !event;
  const [loading, setLoading] = useState(false);
  const [isNameChanges, setIsNameChanges] = useState(false);
  const [storeName, setStoreName] = useState(personalData?.name || "");
  const [address, setAddress] = useState(
    editStoreData?.street_address || ""
  );
  const [city, setCity] = useState(editStoreData?.city || "");
  const [country, setCountry] = useState(editStoreData?.country || "");
  const [pincode, setPincode] = useState(
    editStoreData?.postal_code || ""
  );
  const [state, setState] = useState(editStoreData?.state || "");
  const [latitude, setLatitude] = useState(editStoreData?.latitude || "");
  const [longitude, setLongitude] = useState(editStoreData?.longitude || "");
  const [rows, setRows] = useState([]);
  const [value, setValue] = useState(null);

  //google start
  const [locationLatLang, setLocationLatLang] = React.useState({});
  const [storeAddress, setStoreAddress] = React.useState('');
  const [storeEmail, setStoreEmail] = React.useState(personalData?.email || '');
  const [contactNo, setContactNo] = React.useState(personalData?.contact_no || '');


  const EventSchema = Yup.object().shape({
    title: Yup.string().max(255).required("Name is required"),
    brand: Yup.string().required("Brand is required"),
    price: Yup.number().typeError("you must specify a number"),
    viewed: Yup.number().typeError("you must specify a number"),
    color: Yup.string().max(255),
    productCode: Yup.string().required("Product Code is required"),
  });

  const formik = useFormik({
    initialValues: getInitialValues(event, range),
    validationSchema: EventSchema,
    // onSubmit: async (values, { resetForm, setSubmitting }) => {
    //   try {
    //     const data = {
    //       name: values.name,
    //       street_address: values.street_address,
    //       city: values.city,
    //       country: values.country,
    //       postal_code: values.postal_code,
    //       state: values.state,
    //       latitude: values.latitude,
    //       longitude: values.longitude,
    //     };

    //     if (event) {
    //       // handleUpdate(event.id, data);
    //     } else {
    //       // handleCreate(data);
    //     }

    //     resetForm();
    //     onCancel();
    //     setSubmitting(false);
    //   } catch (error) {
    //     console.error(error);
    //   }
    // },
  });

  const {
    values,
    errors,
    touched,

    isSubmitting,
    getFieldProps,
    setFieldValue,
  } = formik;


  const handleSubmit = async () => {
    setLoading(true);
    try {
      const payload = {
        name: storeName,
        street_address: address,
        city: city,
        country: country,
        postal_code: pincode,
        state: state,
        latitude: latitude,
        longitude: longitude,
        email: storeEmail,
        contact_no: contactNo

      };
      const response = await API.post("/store/create", payload);

      if (response && response.data && response.data.data) {
        handleCloseModal();
        reloadApi();
        setTimeout(() => {
          successAlert("Store added successfully.");
        }, 200);
      } else {
        errorAlert(response.data.message);
      }
      setLoading(false);
    } catch (error) {
      setLoading(false);

      apiErrorHandler(error, "Something went wrong while adding the Store.");
    }
  };

  const handleEditSubmit = async () => {
    setLoading(true);
    try {
      const payload = {
        name: storeName,
        street_address: address,
        city: city,
        country: country,
        postal_code: pincode,
        state: state,
        latitude: latitude,
        longitude: longitude,
        email: storeEmail,
        contact_no: contactNo
      };

      const response = await API.put(
        `/store/update/${editStoreData?.id}`,
        payload
      );
      // debugger
      if (
        response &&
        response.data &&
        (response.data.statusCode === 200 || response.data.statusCode === 204)
      ) {
        handleCloseModal();
        reloadApi();
        setTimeout(() => {
          successAlert("Store updated successfully.");
        }, 200);
      } else {
        if (response.data) {
          errorAlert(response.data.message);
        }
      }
      setLoading(false);
    } catch (error) {
      setLoading(false);

      apiErrorHandler(
        error,
        "Something went wrong while updating the Store"
      );
    }
  };

  const isEdit = editStoreData && editStoreData?.id;
  const handleKeyPress = (event) => {
    if (event?.key === "-" || event?.key === "+") {
      event.preventDefault();
    }
  };

  const handleKeyPressPhone = (event) => {
    if (event?.key === "-") {
      event.preventDefault();
    }
  };




  // const lib = ["places"];
  // const key = "AIzaSyBepTp6ot1oLeiyAXqTlHnQE3mlTeUlFGg"; 
  const openGoogleMap = () => {
    // setIsModal(true);
    if (storeAddress) {
      getData(storeAddress);
    }
  };

  const getData = (val) => {
    var config = {
      method: 'get',
      url: `https://maps.googleapis.com/maps/api/place/findplacefromtext/json?input=${val}&inputtype=textquery&fields=formatted_address%2Cname%2Crating%2Copening_hours%2Cgeometry&key=${GoogleMap_API}`,
      // headers: {
      //   "Access-Control-Allow-Origin": "*",
      //   "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, PATCH, OPTIONS",
      //   "Access-Control-Allow-Headers": "X-Requested-With, content-type, Authorization"
      // }
    };

    axios(config)
      .then(function (response) {
        let addressStore = response.data?.candidates[0]?.formatted_address;
        let latlang = response.data?.candidates[0]?.geometry?.location;
        setStoreAddress(addressStore);
        setAddress(addressStore);
        setLocationLatLang(latlang);
        setLatitude(latlang?.lat);
        setLongitude(latlang?.lng);


        console.log('googleMap', response.data?.candidates[0]?.geometry?.location);
      })
      .catch(function (error) {
        console.log(error);
      });
  };


  return (
    <>


      <FormikProvider value={formik}>

        <LocalizationProvider dateAdapter={AdapterDateFns}>
          <Form autoComplete="off" noValidate>
            <DialogTitle>{isEdit ? "Edit Store" : "Add Store"}</DialogTitle>
            <div className="serchStore">

              <div className="addDiv">
                <TextField
                  fullWidth
                  label="Search Store By google"
                  value={storeAddress}
                  onChange={(e) => {
                    setStoreAddress(e.target.value);
                  }}
                />
              </div>
              <div className="addDiv btns">
                <Button
                  type="button"
                  variant="outlined"
                  onClick={openGoogleMap}
                >
                  Find Store
                </Button>
              </div>
            </div>
            {locationLatLang && Object.keys(locationLatLang).length > 0 && <Map setLongitude={setLongitude} setLatitude={setLatitude} setAddress={setAddress} setStoreAddress={setStoreAddress} locationLatLang={locationLatLang} />}
            {/* {isModal && <Map setAddress={setAddress} setStoreAddress={setStoreAddress} locationLatLang={locationLatLang} />} */}
            <Divider />
            <DialogContent sx={{ p: 3 }}>

              <Grid container spacing={gridSpacing}>
                <Grid item xs={12}>
                  <div style={{ paddingBottom: "10px" }}>
                    <label className="form-label">Name*</label>
                  </div>

                  <TextField
                    fullWidth
                    label="Name"
                    value={storeName}
                    onChange={(e) => {
                      if (isEdit && !isNameChanges) {
                        setIsNameChanges(true);
                      }
                      setStoreName(e.target.value);
                    }}
                    error={Boolean(touched.title && errors.title)}
                    helperText={touched.title && errors.title}
                  />
                </Grid>
              </Grid>
              <Grid container spacing={gridSpacing}>
                <Grid item xs={12}>
                  <div style={{ paddingBottom: "10px" }}>
                    <label className="form-label">Email*</label>
                  </div>

                  <TextField
                    type="email"
                    fullWidth
                    label="Email"
                    value={storeEmail}
                    onChange={(e) => {
                      setStoreEmail(e.target.value);
                    }}
                    error={Boolean(touched.title && errors.title)}
                    helperText={touched.title && errors.title}
                  />
                </Grid>
              </Grid>
              <Grid container spacing={gridSpacing}>
                <Grid item xs={12}>
                  <div style={{ paddingBottom: "10px" }}>
                    <label className="form-label">Phone Number*</label>
                  </div>

                  <TextField
                    onKeyPress={(event) => {
                      handleKeyPressPhone(event);
                    }}
                    type="number"
                    fullWidth
                    label="Phone Number"
                    value={contactNo}
                    onChange={(e) => {
                      setContactNo(e.target.value);
                    }}
                    error={Boolean(touched.title && errors.title)}
                    helperText={touched.title && errors.title}
                  />
                </Grid>
              </Grid>

              <Grid container spacing={gridSpacing}>
                <Grid item xs={12}>
                  <div style={{ paddingBottom: "10px" }}>
                    <label className="form-label">Address*</label>
                  </div>

                  <TextField
                    fullWidth
                    label="Address"
                    value={address}
                    onChange={(e) => {
                      setAddress(e.target.value);
                    }}
                    error={Boolean(touched.title && errors.title)}
                    helperText={touched.title && errors.title}
                  />
                </Grid>
              </Grid>        <Grid container spacing={gridSpacing}>
                <Grid item xs={12}>
                  <div style={{ paddingBottom: "10px" }}>
                    <label className="form-label">City*</label>
                  </div>

                  <TextField
                    fullWidth
                    label="City"
                    value={city}
                    onChange={(e) => {
                      setCity(e.target.value);
                    }}
                    error={Boolean(touched.title && errors.title)}
                    helperText={touched.title && errors.title}
                  />
                </Grid>
              </Grid>        <Grid container spacing={gridSpacing}>
                <Grid item xs={12}>
                  <div style={{ paddingBottom: "10px" }}>
                    <label className="form-label">Country*</label>
                  </div>

                  <TextField
                    fullWidth
                    label="Country"
                    value={country}
                    onChange={(e) => {
                      setCountry(e.target.value);
                    }}
                    error={Boolean(touched.title && errors.title)}
                    helperText={touched.title && errors.title}
                  />
                </Grid>
              </Grid>
              <Grid container spacing={gridSpacing}>
                <Grid item xs={12}>
                  <div style={{ paddingBottom: "10px" }}>
                    <label className="form-label">Postal Code*</label>
                  </div>

                  <TextField
                    onKeyPress={(event) => {
                      handleKeyPress(event);
                    }}
                    type="number"
                    fullWidth
                    label="Postal Code"
                    value={pincode}
                    onChange={(e) => {
                      setPincode(e.target.value);
                    }}
                    error={Boolean(touched.title && errors.title)}
                    helperText={touched.title && errors.title}
                  />
                </Grid>
              </Grid>
              <Grid container spacing={gridSpacing}>
                <Grid item xs={12}>
                  <div style={{ paddingBottom: "10px" }}>
                    <label className="form-label">State*</label>
                  </div>

                  <TextField
                    fullWidth
                    label="State"
                    value={state}
                    onChange={(e) => {
                      setState(e.target.value);
                    }}
                    error={Boolean(touched.title && errors.title)}
                    helperText={touched.title && errors.title}
                  />
                </Grid>
              </Grid>

              <Grid container spacing={gridSpacing}>
                <Grid item xs={12}>
                  <div style={{ paddingBottom: "10px" }}>
                    <label className="form-label">latitude*</label>
                  </div>

                  <TextField
                    onKeyPress={(event) => {
                      handleKeyPress(event);
                    }}
                    type="number"
                    fullWidth
                    label="Latitude"
                    value={latitude}
                    onChange={(e) => {
                      setLatitude(e.target.value);
                    }}
                    error={Boolean(touched.title && errors.title)}
                    helperText={touched.title && errors.title}
                  />
                </Grid>
              </Grid>

              <Grid container spacing={gridSpacing}>
                <Grid item xs={12}>
                  <div style={{ paddingBottom: "10px" }}>
                    <label className="form-label">longitude*</label>
                  </div>

                  <TextField
                    type="number"
                    fullWidth
                    label="Longitude"
                    value={longitude}
                    onKeyPress={(event) => {
                      handleKeyPress(event);
                    }}
                    onChange={(e) => {
                      setLongitude(e.target.value);
                    }}
                    error={Boolean(touched.title && errors.title)}
                    helperText={touched.title && errors.title}
                  />
                </Grid>
              </Grid>
            </DialogContent>

            <DialogActions sx={{ p: 3 }}>
              <Grid container justifyContent="space-between" alignItems="center">
                <Grid item>
                  {!isCreating && (
                    <Tooltip title="Delete Event">
                      <IconButton
                        onClick={() => handleDelete(event?.id)}
                        size="large"
                      >
                        <DeleteIcon color="error" />
                      </IconButton>
                    </Tooltip>
                  )}
                </Grid>
                <Grid item>
                  <Stack direction="row" spacing={2} alignItems="center">
                    <Button
                      type="button"
                      variant="outlined"
                      onClick={handleCloseModal}
                    >
                      Cancel
                    </Button>

                    <LoadingButton
                      size="medium"
                      type="submit"
                      onClick={() => {
                        if (isEdit) {
                          handleEditSubmit();
                        } else {
                          handleSubmit();
                        }
                      }}
                      loading={loading}
                      loadingPosition="center"
                      // startIcon={<SaveIcon />}
                      variant="contained"
                      disabled={!storeName ||
                        !address ||
                        !city ||
                        !state ||
                        !country ||
                        !pincode ||
                        !longitude ||
                        !latitude ||
                        !storeEmail ||
                        !contactNo}
                    >
                      {isEdit ? "Update" : "Add"}
                    </LoadingButton>

                    {/* <Button
                    type="submit"
                    onClick={handleSubmit}
                    variant="contained"
                    disabled={isSubmitting}
                  >
                    {event ? "Edit" : "Add"}
                  </Button> */}
                  </Stack>
                </Grid>
              </Grid>
            </DialogActions>
          </Form>
        </LocalizationProvider>
      </FormikProvider>
    </>
  );
};

export default AddStore;

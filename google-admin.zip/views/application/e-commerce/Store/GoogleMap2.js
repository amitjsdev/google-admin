import React, { useEffect } from 'react';
import { GoogleMap, useLoadScript, Marker, InfoWindow } from '@react-google-maps/api';
// import usePlacesAutocomplete, { getGeocode, getLatLng } from 'use-places-autocomplete';
// import { Combobox, ComboboxInput, ComboboxPopover, ComboboxList, ComboboxOption } from "@reach/combobox";
// import "@reach/combobox/styles.css";
// import './App.css';

const libraries = ['places'];
const mapContainerStyle = {
  width: '72vw',
  height: '100vh',
};
const options = {
  disableDefaultUI: true,
  zoomControl: true,
};
const center = { lat: 55.70927, lng: 9.5357 };

export default function App() {
  const { isLoaded, loadError } = useLoadScript({
    googleMapsApiKey: 'AIzaSyBepTp6ot1oLeiyAXqTlHnQE3mlTeUlFGg',
    libraries,
  });
  const [markers, setMarkers] = React.useState([]);

  const onMapClick = React.useCallback((event) => {
    setMarkers(current => [
      ...current,
      {
        lat: event.latLng.lat(),
        lng: event.latLng.lng(),
        time: new Date(),
      },
    ]);
  }, []);


  const mapRef = React.useRef();
  const onMapLoad = React.useCallback((map) => {
    mapRef.current = map;
  }, []);

  const panTo = React.useCallback(({ lat, lng }) => {
    mapRef.current.panTo({ lat, lng });
    mapRef.current.setZoom(14);
  }, []);

  if (loadError) return 'Error loading maps';
  if (!isLoaded) return 'Loading Maps';

  return (
    <div>

      <Locate panTo={panTo} />
      <GoogleMap
        mapContainerStyle={mapContainerStyle}
        zoom={13}
        center={center}
        onClick={onMapClick}
        onLoad={onMapLoad}
        options={options}
      >
        {markers.map((marker) => (
          <Marker
            key={marker.time.toISOString()}
            position={{
              lat: marker.lat,
              lng: marker.lng
            }}
            icon={{
              url: '/food.png',
              scaledSize: new window.google.maps.Size(20, 20),
              origin: new window.google.maps.Point(0, 0),
              anchor: new window.google.maps.Point(10, 10)
            }}
          />
        ))}
      </GoogleMap>
      <section id="sidebar">
        <h5 className="tc">Restaurant Review</h5>
      </section>
    </div>
  );
}


function Locate({ panTo }) {
  // useEffect(() => {
  //   navigator.geolocation.getCurrentPosition((position) => {
  //     panTo({
  //       lat: position.coords.latitude,
  //       lng: position.coords.longitude,
  //     });
  //   }, () => null, options);
  // }, []);
  return (
    <button className="locate" onClick={() => {
      navigator.geolocation.getCurrentPosition((position) => {
        panTo({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        });
      }, () => null, options);
    }}>
      click
    </button>
  );
}


// /*global google*/
// import ReactDOM from "react-dom";
// import React from "react";

// import { GoogleMap, StandaloneSearchBox, Marker } from "@react-google-maps/api";

// let markerArray = [];
// class Map extends React.Component {
//   state = {
//     currentLocation: { lat: 0, lng: 0 },
//     markers: [],
//     bounds: null
//   };

//   onMapLoad = map => {
//     navigator?.geolocation.getCurrentPosition(
//       ({ coords: { latitude: lat, longitude: lng } }) => {
//         const pos = { lat, lng };
//         this.setState({ currentLocation: pos });
//       }
//     );
//     google.maps.event.addListener(map, "bounds_changed", () => {
//       console.log(map.getBounds());
//       this.setState({ bounds: map.getBounds() });
//     });
//   };

//   onSBLoad = ref => {
//     this.searchBox = ref;
//   };

//   onPlacesChanged = () => {
//     markerArray = [];
//     let results = this.searchBox.getPlaces();
//     for (let i = 0; i < results.length; i++) {
//       let place = results[i].geometry.location;
//       markerArray.push(place);
//     }
//     this.setState({ markers: markerArray });
//     console.log(markerArray);
//   };

//   render() {
//     return (
//       <div>
//         <div id="searchbox">
//           <StandaloneSearchBox
//             onLoad={this.onSBLoad}
//             onPlacesChanged={this.onPlacesChanged}
//             bounds={this.state.bounds}
//           >
//             <input
//               type="text"
//               placeholder="Customized your placeholder"
//               style={{
//                 boxSizing: `border-box`,
//                 border: `1px solid transparent`,
//                 width: `240px`,
//                 height: `32px`,
//                 padding: `0 12px`,
//                 borderRadius: `3px`,
//                 boxShadow: `0 2px 6px rgba(0, 0, 0, 0.3)`,
//                 fontSize: `14px`,
//                 outline: `none`,
//                 textOverflow: `ellipses`,
//                 position: "absolute",
//                 left: "50%",
//                 marginLeft: "-120px"
//               }}
//             />
//           </StandaloneSearchBox>
//         </div>
//         <br />
//         <div>
//           <GoogleMap
//             center={this.state.currentLocation}
//             zoom={10}
//             onLoad={map => this.onMapLoad(map)}
//             mapContainerStyle={{ height: "400px", width: "800px" }}
//           >
//             {this.state.markers.map((mark, index) => (
//               <Marker key={index} position={mark} />
//             ))}
//           </GoogleMap>
//         </div>
//       </div>
//     );
//   }
// }

// export default Map;





// import React from "react";
// import { compose, withProps, lifecycle } from "recompose";
// import { withScriptjs, withGoogleMap, GoogleMap, Marker } from "react-google-maps";


// const MyMapComponent = compose(
//   withProps({
//     googleMapURL: "https://maps.googleapis.com/maps/api/js?key=AIzaSyBepTp6ot1oLeiyAXqTlHnQE3mlTeUlFGg&libraries=geometry,drawing,places",
//     loadingElement: <div style={{ height: `100%` }} />,
//     containerElement: <div style={{ height: `400px` }} />,
//     mapElement: <div style={{ height: `100%` }} />,
//   }),
//   lifecycle({
//     componentWillMount() {
//       const refs = {};

//       this.setState({
//         position: null,
//         onMarkerMounted: ref => {
//           refs.marker = ref;
//         },

//         onPositionChanged: () => {
//           const position = refs.marker.getPosition();
//           console.log(position.toString());
//         }
//       });
//     },
//   }),
//   withScriptjs,
//   withGoogleMap
// )((props) =>
//   <GoogleMap defaultZoom={8} defaultCenter={{ lat: -34.397, lng: 150.644 }}>
//     {props.isMarkerShown && <Marker position={{ lat: -34.397, lng: 150.644 }} draggable={true} ref={props.onMarkerMounted} onPositionChanged={props.onPositionChanged} />}
//   </GoogleMap>
// );

// class MyParentComponentWrapper extends React.PureComponent {
//   state = {
//     isMarkerShown: false,
//   };


//   render() {
//     return (
//       <div>
//         <MyMapComponent isMarkerShown={true} />
//       </div>
//     );
//   }
// }


// export default MyParentComponentWrapper;

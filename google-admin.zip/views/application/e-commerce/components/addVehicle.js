import React, { useEffect, useState } from "react";
import Input from "@mui/material/Input";

import {
  Button,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  Grid,
  IconButton,
  Stack,
  TextField,
  Tooltip,
  Select,
  MenuItem,
} from "@mui/material";
import { DatePicker, LocalizationProvider } from "@mui/lab";
import AdapterDateFns from "@mui/lab/AdapterDateFns";
import { s3 } from "../../../aws/aws-s3";
import API from "../../../../api/axios";
import CloseIcon from "@mui/icons-material/Close";
import uploadIcon from "../../../../assets/images/e-commerce/uploadIcon.svg";

// third-party
import LoadingButton from "@mui/lab/LoadingButton";

// project imports
import { gridSpacing } from "store/constant";
import InputLabel from "@mui/material/InputLabel";

// assets
import DeleteIcon from "@mui/icons-material/Delete";
import { successAlert, apiErrorHandler, errorAlert } from "../../../helpers";

const getMonthYear = ({ fromDate, toDate }) => {
  const start_date = new Date(fromDate);
  const end_date = new Date(toDate);
  return {
    start_date: `${start_date.getFullYear()}-${start_date.getMonth() + 1}`,
    end_date: `${end_date.getFullYear()}-${end_date.getMonth() + 1}`,
  };
};

const AddVehicleData = ({
  event,
  handleDelete,
  handleCloseModal,
  reloadApi,
  editVehicleData,
  vehicleType,
}) => {
  const isCreating = !event;

  const [name, setName] = React.useState("");
  const [type, setType] = React.useState(null);
  const [model, setModel] = React.useState(null);
  const [fromDate, setFromDate] = React.useState(new Date());
  const [toDate, setToDate] = React.useState(new Date());
  const [picUrl, setPicUrl] = React.useState(null);
  const [isUpdated, setIsUpdated] = useState(false);
  const [loading, setLoading] = React.useState(false);

  const onFileChange = async (e) => {
    const file = e.target.files[0];
    if (file && file.size > 20000000) {
      alert("File exceeds 20mb.");
      return;
    }

    s3.uploadFile(file, file.name.trim())
      .then((data) => {
        if (data && data.location) {
          setPicUrl(data.location);
        }
      })
      .catch((err) => {
        apiErrorHandler(err, "Error while uploading images.");
      });
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      let payload = {
        type: type,
        brand: name.trim(),
        model: model,
        ...getMonthYear({ fromDate, toDate })
      };

      if (picUrl) {
        payload = {
          ...payload,
          image: picUrl,
        };
      }
      const response = await API.post("/vehicle-detail/create", payload);
      if (response && response.data && response.data.data) {
        handleCloseModal();
        reloadApi();
        setTimeout(() => {
          successAlert("Vehicle added successfully.");
        }, 200);
      } else {
        errorAlert(response.data.message);
      }
      setLoading(false);
    } catch (error) {
      setLoading(false);

      apiErrorHandler("Something went wrong while adding the Vehicle");
    }
  };

  const handleEditSubmit = async () => {
    setLoading(true);
    try {
      let payload = {
        type: type,
      };

      if (picUrl) {
        payload = {
          ...payload,
          image: picUrl,
        };
      }
      if (isUpdated) {
        payload = {
          ...payload,
          brand: name.trim(),
          model: model,
          ...getMonthYear({ fromDate, toDate })
        };
      }
      const response = await API.put(
        `/vehicle-detail/update/${editVehicleData.id}`,
        payload
      );
      if (
        response &&
        response.data &&
        (response.data.statusCode === 200 || response.data.statusCode === 204)
      ) {
        handleCloseModal();
        reloadApi();
        setTimeout(() => {
          successAlert("Vehicle updated successfully.");
        }, 200);
      } else if (response.data) {
        errorAlert(response.data.message);
      }
      setLoading(false);
    } catch (error) {
      setLoading(false);

      apiErrorHandler(error, "Something went wrong while updating the Vehicle");
    }
  };

  const isEdit = editVehicleData && editVehicleData.id;

  useEffect(() => {
    if (editVehicleData && editVehicleData.id) {
      setName(editVehicleData.brand);
      setModel(editVehicleData.model);
      setType(editVehicleData.type);
      setPicUrl(editVehicleData.image);
      if (editVehicleData.start_date) {
        setFromDate(new Date(editVehicleData.start_date));
      }
      if (editVehicleData.end_date) {
        setToDate(new Date(editVehicleData.end_date));
      }
    }
  }, [editVehicleData.id]);

  return (
    <div>
      <DialogTitle>
        {isEdit ? "Edit Vehicle Data" : "Add Vehicle Data"}
      </DialogTitle>
      <Divider />
      <DialogContent sx={{ p: 3 }}>
        <Grid container spacing={gridSpacing}>
          <Grid item xs={12}>
            <div style={{ paddingBottom: "10px" }}>
              <label className="form-label">Vehicle Brand*</label>
            </div>

            <TextField
              fullWidth
              label="Vehicle Brand"
              value={name}
              onChange={(e) => {
                if (!isUpdated) {
                  setIsUpdated(true);
                }
                setName(e.target.value);
              }}
            />
          </Grid>
          <Grid item xs={12}>
            <div className="form-group">
              <div style={{ paddingBottom: "10px" }}>
                <label className="form-label">Image</label>
              </div>
              <div className="upload-wrap">
                {picUrl ? (
                  <div className="upload-image coverimg">
                    <div className="category-image">
                      <img
                        style={{ maxHeight: "200px", maxWidth: "100%" }}
                        src={picUrl}
                        alt="User Icon"
                      />
                    </div>
                    <div
                      className="close-icon"
                      onClick={() => {
                        setPicUrl("");
                      }}
                    >
                      <CloseIcon />
                    </div>
                  </div>
                ) : (
                  <div
                    className="category-upload-file"
                    style={{ width: "100%" }}
                  >
                    <input
                      type="file"
                      // value={coverInputFile}
                      accept="image/x-png, image/jpg, image/jpeg"
                      onChange={onFileChange}
                      name="sportImage"
                    />
                    <div className="upload-icon">
                      <img src={uploadIcon} alt="Upload Icon" />
                      <p>Upload Image</p>
                    </div>
                  </div>
                )}
                <p className="imgdesc">
                  Maximum size allowed: 20 MB, Format supported: JPEG,PNG, JPG
                  only
                </p>
              </div>
            </div>
          </Grid>
          <Grid item xs={12}>
            <InputLabel htmlFor="name-multiple">Select Type *</InputLabel>

            <Select
              style={{ width: "100%" }}
              labelImainCategoryListd="demo-simple-select-label"
              id="demo-simple-select"
              label="category"
              placeholder={"Select"}
              value={type}
              input={<Input id="name-multiple" />}
              onChange={(event) => setType(event.target.value)}
            >
              {vehicleType &&
                vehicleType.length > 0 &&
                vehicleType.map((m, index) => {
                  return (
                    <MenuItem key={index} value={m.id}>
                      {m.name}
                    </MenuItem>
                  );
                })}
            </Select>
          </Grid>
          <Grid item xs={12}>
            <div style={{ paddingBottom: "10px" }}>
              <label className="form-label">Vehicle Model*</label>
            </div>

            <TextField
              fullWidth
              label="Vehicle Model"
              value={model}
              onChange={(e) => {
                if (!isUpdated) {
                  setIsUpdated(true);
                }
                setModel(e.target.value);
              }}
            />
          </Grid>

          <Grid
            container
            item
            xs={12}
            md={12}
            sx={{ display: "flex", justifyContent: "space-between" }}
          >
            <Grid item xs={12} md={5}>
              <Stack>
                <InputLabel required>From Year</InputLabel>
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                  <DatePicker
                    views={["year", "month"]}
                    inputFormat="MM-yyyy"
                    value={fromDate}
                    maxDate={new Date()}
                    renderInput={(props) => <TextField fullWidth {...props} />}
                    onChange={(newValue) => {
                      if (!isUpdated) {
                        setIsUpdated(true);
                      }
                      setFromDate(newValue);
                    }}
                  />
                </LocalizationProvider>
              </Stack>
            </Grid>
            <Grid item xs={12} md={5}>
              <Stack>
                <InputLabel required>Till Year</InputLabel>
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                  <DatePicker
                    views={["year", "month"]}
                    inputFormat="MM-yyyy"
                    minDate={fromDate}
                    maxDate={new Date()}
                    value={toDate}
                    renderInput={(props) => <TextField fullWidth {...props} />}
                    onChange={(newValue) => {
                      if (!isUpdated) {
                        setIsUpdated(true);
                      }
                      setToDate(newValue);
                    }}
                  />
                </LocalizationProvider>
              </Stack>
            </Grid>
          </Grid>
        </Grid>
      </DialogContent>

      <DialogActions sx={{ p: 3 }}>
        <Grid container justifyContent="space-between" alignItems="center">
          <Grid item>
            {!isCreating && (
              <Tooltip title="Delete Event">
                <IconButton
                  onClick={() => handleDelete(event?.id)}
                  size="large"
                >
                  <DeleteIcon color="error" />
                </IconButton>
              </Tooltip>
            )}
          </Grid>

          <Grid item>
            <Stack direction="row" spacing={2} alignItems="center">
              <Button
                type="button"
                variant="outlined"
                onClick={handleCloseModal}
              >
                Cancel
              </Button>

              <LoadingButton
                size="medium"
                type="submit"
                onClick={() => {
                  if (isEdit) {
                    handleEditSubmit();
                  } else {
                    handleSubmit();
                  }
                }}
                loading={loading}
                loadingPosition="center"
                // startIcon={<SaveIcon />}
                variant="contained"
                disabled={!name || !type || !model || !fromDate || !toDate}
              >
                {isEdit ? "Update Vehicle" : "Add Vehicle"}
              </LoadingButton>
            </Stack>
          </Grid>
        </Grid>
      </DialogActions>
    </div>
  );
};

export default AddVehicleData;

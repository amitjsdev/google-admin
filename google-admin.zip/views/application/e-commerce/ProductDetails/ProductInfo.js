import React, { useState, useEffect } from "react";
import PropTypes from "prop-types";
import { useNavigate } from "react-router-dom";
import API from "../../../../api/axios";
import ProductAdd from "../../customer/Product/ProductAdd";

// material-ui
import { useTheme } from "@mui/material/styles";
import {
  Button,
  ButtonBase,
  //   ButtonGroup,
  Divider,
  //   FormControl,
  //   FormControlLabel,
  //   FormHelperText,
  Grid,
  //   MenuItem,
  //   Radio,
  //   RadioGroup,
  Rating,
  //   Select,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableRow,
  Tooltip,
  Typography,
} from "@mui/material";

// third-party
// import { useFormik, Form, FormikProvider, useField } from "formik";
// import * as yup from "yup";

// project imports
import Chip from "ui-component/extended/Chip";
import Avatar from "ui-component/extended/Avatar";
// import ColorOptions from "../ColorOptions";
// import { openSnackbar } from "store/slices/snackbar";
// import { useDispatch, useSelector } from "store";
// import { addProduct } from "store/slices/cart";
import DeleteModal from "../components/deleteModal";

// assets
import CircleIcon from "@mui/icons-material/Circle";
// import FavoriteBorderIcon from "@mui/icons-material/FavoriteBorder";
import StarTwoToneIcon from "@mui/icons-material/StarTwoTone";
import StarBorderTwoToneIcon from "@mui/icons-material/StarBorderTwoTone";
// import AddIcon from "@mui/icons-material/Add";
// import RemoveIcon from "@mui/icons-material/Remove";
// import ShoppingCartTwoToneIcon from "@mui/icons-material/ShoppingCartTwoTone";
import { successAlert, apiErrorHandler } from "../../../helpers";
// product color select

// function getColor(color) {
//   return ColorOptions.filter((item) => item.value === color);
// }

// product size
// const sizeOptions = [8, 10, 12, 14, 16, 18, 20];

// const validationSchema = yup.object({
//   color: yup.string().required("Color selection is required"),
//   size: yup.number().required("Size selection is required."),
// });

// ==============================|| COLORS OPTION ||============================== //

const Colors = ({ checked, colorsData }) => {
  const theme = useTheme();
  return (
    <Grid item>
      <Tooltip title={colorsData[0].label}>
        <ButtonBase sx={{ borderRadius: "50%" }}>
          <Avatar
            color="inherit"
            size="badge"
            sx={{
              bgcolor: colorsData[0].bg,
              color: theme.palette.mode === "light" ? "grey.50" : "grey.800",
            }}
          >
            {checked && (
              <CircleIcon
                sx={{
                  color:
                    theme.palette.mode === "light" ? "grey.50" : "grey.800",
                  fontSize: "0.75rem",
                }}
              />
            )}
            {!checked && (
              <CircleIcon
                sx={{ color: colorsData[0].bg, fontSize: "0.75rem" }}
              />
            )}
          </Avatar>
        </ButtonBase>
      </Tooltip>
    </Grid>
  );
};

Colors.propTypes = {
  checked: PropTypes.bool,
  colorsData: PropTypes.array,
};

// const Increment = (props) => {
//     const [field, , helpers] = useField(props);

//     const { value } = field;
//     const { setValue } = helpers;
//     return (
//         <ButtonGroup size="large" variant="text" color="inherit" sx={{ border: '1px solid', borderColor: 'grey.400' }}>
//             <Button
//                 key="three"
//                 disabled={value <= 1}
//                 onClick={() => setValue(value - 1)}
//                 sx={{ pr: 0.75, pl: 0.75, minWidth: '0px !important' }}
//             >
//                 <RemoveIcon fontSize="inherit" />
//             </Button>
//             <Button key="two" sx={{ pl: 0.5, pr: 0.5 }}>
//                 {value}
//             </Button>
//             <Button key="one" onClick={() => setValue(value + 1)} sx={{ pl: 0.75, pr: 0.75, minWidth: '0px !important' }}>
//                 <AddIcon fontSize="inherit" />
//             </Button>
//         </ButtonGroup>
//     );
// };

const ProductInfo = ({ getProductDetail,product, productInfo = {} }) => {
  //   const dispatch = useDispatch();
  const history = useNavigate();
  const [open, setOpen] = React.useState(false);
  const handleClickOpenDialog = () => {
    setOpen(true);
  };
  const handleCloseDialog = () => {
    setOpen(false);
  };

  //   const cart = useSelector((state) => state.cart);

  // const formik = useFormik({
  //     enableReinitialize: true,
  //     initialValues: {
  //         id: product.id,
  //         name: product.name,
  //         image: product.image,
  //         salePrice: product.salePrice,
  //         offerPrice: product.offerPrice,
  //         color: '',
  //         size: '',
  //         quantity: 1
  //     },
  //     validationSchema,
  //     onSubmit: (values) => {
  //         dispatch(addProduct(values, cart.checkout.products));
  //         dispatch(
  //             openSnackbar({
  //                 open: true,
  //                 message: 'Submit Success',
  //                 variant: 'alert',
  //                 alert: {
  //                     color: 'success'
  //                 },
  //                 close: false
  //             })
  //         );

  //         history('/e-commerce/checkout');
  //     }
  // });

  // const { values, errors, handleSubmit, handleChange } = formik;

  //   const addCart = () => {
  // values.color = values.color ? values.color : 'primaryDark';
  // values.size = values.size ? values.size : '8';
  // dispatch(addProduct(values, cart.checkout.products));
  // dispatch(
  //     openSnackbar({
  //         open: true,
  //         message: 'Add To Cart Success',
  //         variant: 'alert',
  //         alert: {
  //             color: 'success'
  //         },
  //         close: false
  //     })
  // );
  //   };

  const [colorList, setColorList] = useState([]);
  const [deleteModal, setDeleteModal] = useState(false);

  // const handleColorList = async () => {
  //   try {
  //     const response = await API.get("/color/get-list");
  //     if (response && response.data && response.data.data) {
  //       const productData = response.data.data.reverse();
  //       setColorList(productData);
  //     }
  //   } catch (error) {
  //     alert("Something went wrong while getting the colors List");
  //   }
  // };

  // useEffect(() => {
  //   handleColorList();
  // }, []);

  const handleDelete = async () => {
    try {
      const response = await API.delete(`/product/delete/${productInfo.id}`);
      if (response && response.status === 200) {
        setDeleteModal(false);
        setTimeout(() => {
          successAlert("Product deleted successfully.");
          history("/products");
        }, 300);
      }
    } catch (error) {
      apiErrorHandler(
        error,
        "Something went wrong while deleting the Product."
      );
    }
  };

  const handleListInText = () => {
    if (productInfo.sections["latest"] && productInfo.sections["trending"]) {
      return "Latest, Trending";
    } else if (productInfo.sections["latest"]) {
      return "Latest";
    } else if (productInfo.sections["trending"]) {
      return "Trending";
    }
    return "";
  };

  return (
    <>
      {open && (
        <ProductAdd
          open={open}
          handleCloseDialog={handleCloseDialog}
          productInfo={productInfo}
          getProductDetail={getProductDetail}
        />
      )}
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <Stack
            direction="row"
            alignItems="center"
            justifyContent="space-between"
          >
            <Grid container spacing={1}>
              <Grid item xs={12}>
                {productInfo && productInfo.availability && (
                  <Chip
                    size="small"
                    label={
                      productInfo.availability.toLowerCase() === "yes"
                        ? "In Stock"
                        : "Out of Stock"
                    }
                    chipcolor={
                      productInfo.availability.toLowerCase() === "yes"
                        ? "success"
                        : "error"
                    }
                    sx={{ borderRadius: "4px", textTransform: "capitalize" }}
                  />
                )}
              </Grid>
              <Grid item xs={12}>
                <Stack direction="row" alignItems="center" spacing={1}>
                  <Typography variant="h3">{productInfo.name}</Typography>
                  <Chip
                    size="small"
                    label="New"
                    chipcolor="primary"
                    variant="outlined"
                  />
                </Stack>
              </Grid>
            </Grid>
            {/* <Avatar variant="rounded" sx={{ bgcolor: 'grey.200', color: 'grey.800' }}>
                        <FavoriteBorderIcon />
                    </Avatar> */}
          </Stack>
        </Grid>
        <Grid item xs={12}>
          <Typography variant="body2">{productInfo.detail}</Typography>
        </Grid>
        <Grid item xs={12}>
          <Stack direction="row" alignItems="center" spacing={1}>
            <Rating
              name="simple-controlled"
              value={parseFloat(productInfo.ratings)}
              icon={<StarTwoToneIcon fontSize="inherit" />}
              emptyIcon={<StarBorderTwoToneIcon fontSize="inherit" />}
              precision={0.1}
              readOnly
            />
            <Typography variant="caption">({productInfo.ratings}+)</Typography>
          </Stack>
        </Grid>
        <Grid item xs={12}>
          <Stack direction="row" alignItems="center" spacing={1}>
            <Typography variant="h2" color="primary">
              ${productInfo.discounted_price}
            </Typography>
            <Typography variant="body1" sx={{ textDecoration: "line-through" }}>
              ${productInfo.original_price}
            </Typography>
            <Typography variant="caption">(Inclusive of all taxes)</Typography>
          </Stack>
        </Grid>
        <Grid item xs={12}>
          <Divider />
        </Grid>
        <Grid item xs={12}>
          {/* <FormikProvider value={formik}> */}
          {/* <Form autoComplete="off" noValidate > */}
          <Grid container spacing={2}>
            <Grid item xs={12} lg={10}>
              <Table>
                <TableBody
                  sx={{ "& .MuiTableCell-root": { borderBottom: "none" } }}
                >
                  <TableRow>
                    <TableCell>
                      <Typography variant="body2">Colors Avalaible:</Typography>
                    </TableCell>
                    {productInfo && productInfo.colors && (
                      <TableCell align="left">
                        {
                          productInfo?.colors.length > 0 &&
                          productInfo?.colors.map((item, index) => {
                            return (
                              <>
                                {item?.image && item.image.includes('http') ?

                                  <img
                                    style={{
                                      paddingRight: "10px",
                                      maxHeight: "50px",
                                    }}
                                    src={item.image}
                                    alt="productImg"
                                  />
                                  :
                                  item?.name
                                }
                              </>
                            );
                          })}
                      </TableCell>
                    )}
                  </TableRow>
                  <TableRow>
                    <TableCell>
                      <Typography variant="body2">Category: </Typography>
                    </TableCell>
                    <TableCell>
                      {productInfo.category && productInfo.category.name}
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>
                      <Typography variant="body2">Brand: </Typography>
                    </TableCell>
                    <TableCell>{productInfo.brand}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>
                      <Typography variant="body2">Product Code: </Typography>
                    </TableCell>
                    <TableCell>{productInfo.product_code}</TableCell>
                  </TableRow>

                  <TableRow>
                    <TableCell>
                      <Typography variant="body2">Quantity: </Typography>
                    </TableCell>
                    <TableCell align="left">{productInfo.quantity}</TableCell>
                  </TableRow>
                  {productInfo.sections &&
                    (productInfo.sections["latest"] ||
                      productInfo.sections["trending"]) && (
                      <TableRow>
                        <TableCell align="left">
                          <Typography variant="body2">Listed in: </Typography>
                        </TableCell>
                        <TableCell>{handleListInText()}</TableCell>
                      </TableRow>
                    )}
                  {productInfo.tags && productInfo.tags.length > 0 && (
                    <TableRow>
                      <TableCell>
                        <Typography variant="body2">Tags: </Typography>
                      </TableCell>
                      <TableCell align="left">
                        {productInfo.tags && productInfo.tags.join(", ")}
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </Grid>
            <Grid item xs={12}>
              <Divider />
            </Grid>
            <Grid item xs={12}>
              <Grid container spacing={1}>
                <Grid item xs={6}>
                  <Button
                    type="submit"
                    // onClick={() => {
                    //       history('/products')
                    // }}
                    fullWidth
                    color="secondary"
                    variant="contained"
                    size="large"
                    onClick={handleClickOpenDialog}
                  >
                    Edit Product
                  </Button>
                </Grid>
                <Grid item xs={6}>
                  <Button
                    onClick={() => setDeleteModal(true)}
                    type="submit"
                    fullWidth
                    color="secondary"
                    variant="contained"
                    size="large"
                  >
                    Delete Product
                  </Button>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
          {/* </Form> */}
          {/* </FormikProvider> */}
        </Grid>
      </Grid>
      {deleteModal && (
        <DeleteModal
          handleDelete={handleDelete}
          title="Delete Product"
          open={deleteModal}
          setOpen={setDeleteModal}
          type="Product"
        />
      )}
    </>
  );
};

ProductInfo.propTypes = {
  product: PropTypes.object,
};

export default ProductInfo;

import * as React from 'react';
import { CKEditor } from '@ckeditor/ckeditor5-react';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
export default function RichTextEditor({ productInfo,name, onChangeEditor }) {

    return (
        <CKEditor
            editor={ClassicEditor}
            data={productInfo}
            onChange={(event, editor) => {
                const data = editor.getData();
                onChangeEditor(name,data)
                console.log('getData', data)
            }}
        />
    );
}

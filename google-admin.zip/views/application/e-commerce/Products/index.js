import React from "react";

import { useEffect, useState } from "react";
// material-ui
import { styled, useTheme } from "@mui/material/styles";
import {
  Box,
  Button,
  Divider,
  Grid,
  IconButton,
  InputAdornment,
  Menu,
  MenuItem,
  Stack,
  TextField,
  Typography,
  useMediaQuery,
  Tooltip,
  Fab,
} from "@mui/material";

// project imports
import SortOptions from "./SortOptions";
import ProductEmpty from "./ProductEmpty";
import ProductCard from "ui-component/cards/ProductCard";

import SkeletonProductPlaceholder from "ui-component/cards/Skeleton/ProductPlaceholder";

import { resetCart } from "store/slices/cart";
import { useDispatch, useSelector } from "store";
import ProductAdd from "views/application/customer/Product/ProductAdd";
import { appDrawerWidth, gridSpacing } from "store/constant";
import { getProducts, filterProducts } from "store/slices/product";
import API from "../../../../api/axios";

// assets
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import FilterAltIcon from "@mui/icons-material/FilterAlt";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import SearchIcon from "@mui/icons-material/Search";
import AddIcon from "@mui/icons-material/AddTwoTone";

// product list container
const Main = styled("main", { shouldForwardProp: (prop) => prop !== "open" })(
  ({ theme, open }) => ({
    flexGrow: 1,
    transition: theme.transitions.create("margin", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.shorter,
    }),
    marginRight: -appDrawerWidth,
    [theme.breakpoints.down("xl")]: {
      paddingRight: 0,
      marginRight: 0,
    },
    ...(open && {
      transition: theme.transitions.create("margin", {
        easing: theme.transitions.easing.easeOut,
        duration: theme.transitions.duration.shorter,
      }),
      marginRight: 0,
    }),
  })
);

// ==============================|| E-COMMERCE - PRODUCT GRID ||============================== //

const ProductsList = () => {
  const theme = useTheme();
  const dispatch = useDispatch();
  const cart = useSelector((state) => state.cart);

  const matchDownSM = useMediaQuery(theme.breakpoints.down("md"));
  const matchDownMD = useMediaQuery(theme.breakpoints.down("lg"));
  const matchDownLG = useMediaQuery(theme.breakpoints.down("xl"));

  const [isLoading, setLoading] = useState(true);

  // drawer
  const [open, setOpen] = useState(isLoading);

  const handleDrawerOpen = () => {
    setOpen((prevState) => !prevState);
  };
  const [productsList, setProductsList] = React.useState([]);

  useEffect(() => {
    dispatch(getProducts());

    // hide left drawer when email app opens
    // dispatch(openDrawer(false));

    // clear cart if complete order
    if (cart.checkout.step > 2) {
      dispatch(resetCart());
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // filter
  const initialState = {
    search: "",
    sort: "low",
    gender: [],
    categories: ["all"],
    colors: [],
    price: "",
    rating: 0,
  };
  const [filter, setFilter] = useState(initialState);

  // search filter
  const handleSearch = async (event) => {
    const newString = event?.target.value;
    setFilter({ ...filter, search: newString });
  };

  // sort options
  const [anchorEl, setAnchorEl] = useState(null);
  const [addOpen, setAddOpen] = useState(false);
  const openSort = Boolean(anchorEl);
  const handleClickListItem = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const filterData = async () => {
    await dispatch(filterProducts(filter));
    setLoading(false);
  };

  useEffect(() => {
    filterData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter]);

  useEffect(() => {
    setOpen(!matchDownLG);
  }, [matchDownLG]);

  // sort filter
  const handleMenuItemClick = (event, index) => {
    setFilter({ ...filter, sort: index });
    setAnchorEl(null);
  };

  const sortLabel = SortOptions.filter((items) => items.value === filter.sort);

  let productResult = <></>;
  if (productsList && productsList.length > 0) {
    productResult = productsList.map((product, index) => (
      <Grid key={index} item xs={12} sm={6} md={4} lg={3}>
        <ProductCard
          id={product.id}
          image={
            product.pictures && product.pictures.length > 0
              ? product.pictures[0]
              : null
          }
          name={product.name}
          description={product.detail}
          offerPrice={product.discounted_price}
          salePrice={product.original_price}
          rating={product.ratings}
          color={product.colors ? "black" : undefined}
        />
      </Grid>
    ));
  } else {
    productResult = (
      <Grid item xs={12} sx={{ mt: 3 }}>
        <ProductEmpty />
      </Grid>
    );
  }

  const spacingMD = matchDownMD ? 1 : 1.5;

  const handleProductList = async () => {
    try {
      const response = await API.get("/product/get-list");
      if (response && response.data && response.data.data) {
        const productData = response.data.data.reverse();
        setProductsList(productData);
      }
    } catch (error) {
      alert("Something went wrong while getting the product List");
    }
  };

  React.useEffect(() => {
    handleProductList();
  }, []);

  const handleClickOpenDialog = () => {
    setAddOpen(true);
  };
  const handleCloseDialog = () => {
    setAddOpen(false);
    handleProductList();
  };

  return (
    <Grid container spacing={2}>
      <Grid item xs={12}>
        <Grid
          container
          alignItems="center"
          justifyContent="space-between"
          spacing={matchDownMD ? 0.5 : 2}
        >
          <Grid item>
            <Stack direction="row" alignItems="center" spacing={1}>
              <Typography variant="h4">Shop</Typography>
              <IconButton size="large">
                <ArrowForwardIosIcon
                  sx={{
                    width: "0.875rem",
                    height: "0.875rem",
                    fontWeight: 500,
                    color: "grey.500",
                  }}
                />
              </IconButton>
            </Stack>
          </Grid>
          <Grid item>
            <Stack
              direction="row"
              alignItems="center"
              justifyContent="center"
              spacing={matchDownSM ? 0.5 : spacingMD}
            >
              <TextField
                sx={{ width: { xs: 140, md: "auto" } }}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon fontSize="small" />
                    </InputAdornment>
                  ),
                }}
                value={filter.search}
                placeholder="Search Product"
                size="small"
                onChange={handleSearch}
              />

              <Typography
                sx={{
                  pl: 1.5,
                  fontSize: "1rem",
                  color: "grey.500",
                  fontWeight: 400,
                }}
              >
                |
              </Typography>

              <Button
                disableRipple
                onClick={handleDrawerOpen}
                color="secondary"
                startIcon={
                  <FilterAltIcon
                    sx={{ fontWeight: 500, color: "secondary.200" }}
                  />
                }
              >
                Filter
              </Button>

              <Typography
                sx={{
                  display: { xs: "none", sm: "flex" },
                  fontSize: "1rem",
                  color: "grey.500",
                  fontWeight: 400,
                }}
              >
                |
              </Typography>
              <Stack
                direction="row"
                alignItems="center"
                justifyContent="center"
                sx={{ display: { xs: "none", sm: "flex" } }}
              >
                <Typography variant="h5">Sort by: </Typography>
                <Button
                  id="demo-positioned-button"
                  aria-controls="demo-positioned-menu"
                  aria-haspopup="true"
                  aria-expanded={openSort ? "true" : undefined}
                  onClick={handleClickListItem}
                  sx={{ color: "grey.500", fontWeight: 400 }}
                  endIcon={<KeyboardArrowDownIcon />}
                >
                  {sortLabel.length > 0 && sortLabel[0].label}
                </Button>
                <Menu
                  id="demo-positioned-menu"
                  aria-labelledby="demo-positioned-button"
                  anchorEl={anchorEl}
                  open={openSort}
                  onClose={handleClose}
                  anchorOrigin={{
                    vertical: "bottom",
                    horizontal: "right",
                  }}
                  transformOrigin={{
                    vertical: "top",
                    horizontal: "right",
                  }}
                >
                  {SortOptions.map((option, index) => (
                    <MenuItem
                      sx={{ p: 1.5 }}
                      key={index}
                      selected={option.value === filter.sort}
                      onClick={(event) =>
                        handleMenuItemClick(event, option.value)
                      }
                    >
                      {option.label}
                    </MenuItem>
                  ))}
                </Menu>
              </Stack>
              <Tooltip title="Add Product">
                <Fab
                  color="primary"
                  size="small"
                  onClick={handleClickOpenDialog}
                  sx={{
                    boxShadow: "none",
                    ml: 1,
                    width: 32,
                    height: 32,
                    minHeight: 32,
                  }}
                >
                  <AddIcon fontSize="small" />
                </Fab>
              </Tooltip>
              <ProductAdd
                open={addOpen}
                handleCloseDialog={handleCloseDialog}
              />
            </Stack>
          </Grid>
        </Grid>
      </Grid>
      <Grid item xs={12}>
        <Divider sx={{ borderColor: "grey.400" }} />
      </Grid>
      <Grid item xs={12}>
        <Box sx={{ display: "flex" }}>
          <Main open={open}>
            {/* <ProductFilterView
              filter={filter}
              filterIsEqual={filterIsEqual}
              handelFilter={handelFilter}
              initialState={initialState}
            /> */}
            <Grid container spacing={gridSpacing}>
              {isLoading
                ? productsList &&
                  productsList.length > 0 &&
                  productsList.map((item) => (
                    <Grid key={item} item xs={12} sm={6} md={4} lg={3}>
                      <SkeletonProductPlaceholder />
                    </Grid>
                  ))
                : productResult}
            </Grid>
          </Main>
        </Box>
      </Grid>
    </Grid>
  );
};

export default ProductsList;

import * as React from "react";

// project imports
import MainCard from "ui-component/cards/MainCard";

const AddProduct = () => {

  return (
    <MainCard title="Add Product" content={false}>
        </MainCard>
  );
};

export default AddProduct;

import PropTypes from "prop-types";
import { forwardRef, useEffect, useState } from "react";
import ImageUploader from "./ImageInput";
import VideoUploader from "./VideoInput";
import LoadingButton from "@mui/lab/LoadingButton";

// material-ui

import {
  Button,
  Chip,
  FormControlLabel,
  Checkbox,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Grid,
  Input,
  InputAdornment,
  MenuItem,
  Select,
  Slide,
  TextField,
  Typography,
} from "@mui/material";

import API from "../../../../api/axios";

// project imports
import { gridSpacing } from "store/constant";
import { useNavigate } from "react-router-dom";
import AnimateButton from "ui-component/extended/AnimateButton";
import Avatar from "ui-component/extended/Avatar";

// assets
import { apiErrorHandler, successAlert, errorAlert } from "../../../helpers";
import RichTextEditor from "views/application/e-commerce/ProductDetails/RichTextEditor";

// animation
const Transition = forwardRef((props, ref) => (
  <Slide direction="left" ref={ref} {...props} />
));

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
  chip: {
    margin: 2,
  },
};

// tags list & style
const tagNames = ["Cars", "Black Covers", "Leather Cover", "Accesories"];

// ==============================|| PRODUCT ADD DIALOG ||============================== //

const ProductAdd = ({getProductDetail, open, handleCloseDialog, productInfo = {} }) => {
  const availabilty = ["Yes", "No"];

  // set image upload progress
  // const [progress, setProgress] = useState(0);

  const [categoryList, setCategoryList] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [vehicleList, setVehicleList] = useState([]);
  const [colorList, setColorList] = useState([]);
  const [materialList, setMaterialList] = useState([]);

  const navigate = useNavigate();

  const handleCategoryList = async () => {
    try {
      const response = await API.get("/category/get-list");
      if (response && response.data && response.data.data) {
        const categoryData = response.data.data.reverse();
        setCategoryList(categoryData);
      }
    } catch (error) {
      apiErrorHandler(
        error,
        "Something went wrong while getting the Category List"
      );
    }
  };

  const handleVehicleType = async () => {
    try {
      const response = await API.get("vehicle-detail/vehicle-types");
      if (response && response.data && response.status === 200) {
        if (
          response &&
          response.data &&
          response.data.data &&
          response.data.data.length > 0
        ) {
          setVehicles(response.data.data);
        } else {
          setVehicles([]);
        }
      }
    } catch (error) {
      apiErrorHandler(
        error,
        "Something went wrong while getting the vehicle type"
      );
    }
  };

  const handleColorList = async () => {
    try {
      const response = await API.get("/color/get-list");

      if (response && response.data && response.data.data) {
        const colorDara = response.data.data.reverse();
        setColorList(colorDara);
      }
    } catch (error) {
      apiErrorHandler(
        error,
        "Something went wrong while getting the Color List"
      );
    }
  };

  const handleVehicleList = async () => {
    try {
      const response = await API.get("vehicle-detail/get-list");
      if (response && response.data && response.data.data) {
        const vehicleData = response.data.data.reverse();
        setVehicleList(vehicleData);
      }
    } catch (error) {
      alert("Something went wrong while getting the Vehicle List");
    }
  };

  const handleMaterialList = async () => {
    try {
      const response = await API.get("material/get-list");
      if (response && response.data && response.data.data) {
        const materialData = response.data.data.reverse();
        setMaterialList(materialData);
      }
    } catch (error) {
      alert("Something went wrong while getting the Material List");
    }
  };

  useEffect(() => {
    handleCategoryList();
    handleVehicleType();
    handleVehicleList();
    handleColorList();
    handleMaterialList();
  }, []);

  // handle tag select
  const [productName, setProductName] = useState(productInfo.name || "");
  const [productDescription, setProductDescription] = useState(
    productInfo.description || ""
  );
  const [productDetail, setProductDetail] = useState(productInfo.detail || "");

  const [additionalInfo, setAdditionalInfo] = useState(
    productInfo.additional_info || ""
  );
  const [category, setCategory] = useState(productInfo.category?.id || null);
  const [vehicleType, setVehicleType] = useState(
    productInfo.vehicle_type || null
  );
  const [ratings, setRatings] = useState(productInfo.ratings || null);
  const [productCode, setProductCode] = useState(
    productInfo.product_code || null
  );
  const [quantity, setQuantity] = useState(productInfo.quantity || null);
  const [brand, setBrand] = useState(productInfo.brand || "");
  const [orignalPrice, setOrignailPrice] = useState(
    productInfo.original_price || null
  );
  const [discountPrice, setDiscountPrice] = useState(
    productInfo.discounted_price || null
  );
  const [tags, setTags] = useState(productInfo.tags || []);
  const [majorColors, setMajorColors] = useState(productInfo.major_color || []);

  const [colors, setColors] = useState(productInfo.colors || []);
  const [minorColors, setMinorColors] = useState(productInfo.minor_color || []);
  const [suggestions, setSuggestions] = useState(productInfo.suggestions || []);
  const [isAvailabilty, setAvailability] = useState(
    productInfo.availability || null
  );
  const [materials, setMaterials] = useState(productInfo.material || []);
  const [images, setImages] = useState(productInfo.pictures || []);
  const [loading, setLoading] = useState(false);
  const [videos, setVideos] = useState(productInfo.videos || []);

  const [section, setSection] = useState({
    trending: productInfo.sections?.trending || false,
    latest: productInfo.sections?.latest || false,
  });

  // const  = (event) => {
  //   setAvailability(event?.target.value);
  // };

  const handleCreateProduct = async () => {
    setLoading(true);
    try {
      const payload = {
        category_id: category,
        name: productName.trim(),
        ratings: parseFloat(ratings),
        pictures: images,
        videos: videos,
        original_price: parseFloat(orignalPrice),
        discounted_price: parseFloat(discountPrice),
        material: materials,
        detail: productDetail,
        description: productDescription,
        vehicle_type: vehicleType,
        major_color: majorColors,
        minor_color: minorColors,
        brand: brand,
        product_code: productCode,
        availability: isAvailabilty,
        viewed: 10,
        colors,
        quantity: quantity,
        reviews: [],
        tags,
        suggestions: suggestions,
        sections: section,
        additional_info: additionalInfo,
      };
      let response;

      if (productInfo.id) {
        response = await API.put(
          `/product/update/${productInfo.id}`,
          payloadData
        );

        if (productInfo.id && response.data.statusCode === 204) {
          setTimeout(() => {
            successAlert(`Product updated successfully.`);
            handleCloseDialog();
            getProductDetail();
          }, 200);
        } else {
          errorAlert(response.data.message);
        }
      } else {
        response = await API.post("/product/create", payload);
        if (response && response.data && response.data.data) {
          setTimeout(() => {
            successAlert(`Product added successfully.`);
            handleCloseDialog();
          }, 200);
        } else {
          errorAlert(response.data.message);
        }
      }
      setLoading(false);
    } catch (error) {
      setLoading(false);

      apiErrorHandler(
        error,
        `Something went wrong while ${productInfo.id ? "updating" : "adding"
        } the Product`
      );
    }
  };

  const handleImages = (data) => {
    setImages(data);
    if (productInfo.id) {
      onChangeFormData("", "", data);
    }
  };

  const handleVideos = (data) => {
    setVideos(data);
    if (productInfo.id) {
      onChangeFormData("", "", "", data);
    }
  };
  const [payloadData, setPayloadData] = useState({});

  const onChangeFormData = (e, setData, isImage = false, isVideo = false) => {
    let data = { ...payloadData };
    if (isImage) {
      data["pictures"] = isImage;
      setPayloadData(data);
      return;
    } else if (isVideo) {
      data["videos"] = isVideo;
      setPayloadData(data);
      return;
    } else {

      console.log('productInfo', productInfo)
      if (productInfo.id) {
        if (e == 'description') {
          setProductDescription(setData);
          setPayloadData({ description: setData });
        } else if (e == 'additional_info') {
          setAdditionalInfo(setData);
          setPayloadData({...payloadData, additional_info: setData });
        } else {
          const { value, name } = e?.target;

          let data = { ...payloadData };
          if (name === "ratings") {
            data[name] = parseFloat(value);
          } else if (name === "latest" || name === "trending") {
            const sectionData = { ...section };
            sectionData[name] = e.target.checked;
            setData(sectionData);
            data["sections"] = sectionData;
            setPayloadData(data);
            return;
          } else {
            data[name] = value;
          }
          setData(value);
          setPayloadData(data);
        }

      } else {
        if (e == 'description') {
          setProductDescription(setData);
        } else if (e == 'additional_info') {
          setAdditionalInfo(setData);
        } else {
          const { value, name } = e?.target;
          if (name === "latest" || name === "trending") {
            const sectionData = { ...section };
            sectionData[name] = e.target.checked;
            setData(sectionData);
            return;
          } else {
            setData(value);
          }
        }
      }


    }
  };

  const handleKeyPress = (event) => {
    if (event?.key === "-" || event?.key === "+") {
      event.preventDefault();
    }
  };

  return (
    <Dialog
      open={open}
      TransitionComponent={Transition}
      keepMounted
      onClose={handleCloseDialog}
      sx={{
        "&>div:nth-of-type(3)": {
          justifyContent: "flex-end",
          "&>div": {
            m: 0,
            borderRadius: "0px",
            maxWidth: 550,
            maxHeight: "100%",
          },
        },
      }}
    >
      {open && (
        <>
          <DialogTitle>
            {productInfo.id ? "Edit Product" : "Add Product"}
          </DialogTitle>
          <DialogContent>
            <Grid container spacing={gridSpacing} sx={{ mt: 0.25 }}>
              <Grid item xs={12}>
                <TextField
                  id="outlined-basic1"
                  fullWidth
                  label="Product Name*"
                  name="name"
                  value={productName}
                  onChange={(event) => onChangeFormData(event, setProductName)}
                />
              </Grid>
              <Grid item xs={12}>
                <span className="richTitle">Product Description*</span>
                <RichTextEditor
                  productInfo={productDescription}
                  name="description"
                  onChangeEditor={onChangeFormData}
                />
                {/* <TextField
                  id="outlined-basic2"
                  fullWidth
                  multiline
                  name="description"
                  rows={3}
                  value={productDescription}
                  label="Product Description*"
                  onChange={(event) =>
                    onChangeFormData(event, setProductDescription)
                  }
                /> */}
              </Grid>
              <Grid item xs={12}>
                <TextField
                  id="outlined-basic2"
                  fullWidth
                  multiline
                  rows={2}
                  name="detail"
                  value={productDetail}
                  label="Product Detail"
                  onChange={(event) =>
                    onChangeFormData(event, setProductDetail)
                  }
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  id="standard-select-currency"
                  select
                  value={category}
                  name="category_id"
                  label="Select Category*"
                  fullWidth
                  onChange={(event) => onChangeFormData(event, setCategory)}
                >
                  {categoryList &&
                    categoryList.length > 0 &&
                    categoryList.map((option) => (
                      <MenuItem
                        key={option.id}
                        value={option.id}
                        selected={
                          category && category === option.id ? true : false
                        }
                      >
                        {option.name}
                      </MenuItem>
                    ))}
                </TextField>
              </Grid>

              <Grid item xs={12}>
                <TextField
                  id="standard-select-currency"
                  select
                  label="Select Vehicles Type*"
                  name="vehicle_type"
                  value={vehicleType}
                  fullWidth
                  onChange={(event) => onChangeFormData(event, setVehicleType)}
                >
                  {vehicles &&
                    vehicles.length > 0 &&
                    vehicles.map((option) => (
                      <MenuItem
                        key={option.id}
                        value={option.id}
                        selected={
                          vehicleType && vehicleType === option.id
                            ? true
                            : false
                        }
                      >
                        {option.name}
                      </MenuItem>
                    ))}
                </TextField>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  type="number"
                  id="outlined-basic2"
                  inputProps={{
                    inputMode: "numeric",
                    pattern: "[0-9]*",
                    min: 0,
                    max: 5,
                    step: 0.1,
                  }}
                  fullWidth
                  onKeyPress={(event) => {
                    handleKeyPress(event);
                  }}
                  value={ratings}
                  name="ratings"
                  rows={1}
                  onChange={(e) => {
                    if (
                      e &&
                      e.target &&
                      e.target.value > 0 &&
                      e.target.value <= 5
                    ) {
                      onChangeFormData(e, setRatings);
                    }
                    // need check  setRatings(parseFloat(e.target.value))
                  }}
                  label="Product Ratings*"
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  id="outlined-basic3"
                  fullWidth
                  label="Product Code*"
                  name="product_code"
                  value={productCode}
                  onChange={(e) => onChangeFormData(e, setProductCode)}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  id="outlined-basic1"
                  type="number"
                  name="quantity"
                  onKeyPress={(event) => {
                    handleKeyPress(event);
                  }}
                  InputProps={{ inputProps: { min: 1 } }}
                  value={quantity}
                  fullWidth
                  label="Quantity*"
                  onChange={(e) => {
                    onChangeFormData(e, setQuantity);
                  }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  id="outlined-basic4"
                  name="brand"
                  fullWidth
                  label="Brand*"
                  value={brand}
                  onChange={(e) => onChangeFormData(e, setBrand)}
                />
              </Grid>
              <Grid item md={6} xs={12}>
                <TextField
                  label="Orignal Price*"
                  id="filled-start-adornment1"
                  type="number"
                  name="original_price"
                  value={orignalPrice}
                  onChange={(e) => onChangeFormData(e, setOrignailPrice)}
                  InputProps={
                    ({
                      startAdornment: (
                        <InputAdornment position="start"></InputAdornment>
                      ),
                    },
                      { inputProps: { min: 0 } })
                  }
                  onKeyPress={(event) => {
                    handleKeyPress(event);
                  }}
                />
              </Grid>

              <Grid item md={6} xs={12}>
                <TextField
                  label="Discount Price"
                  id="filled-start-adornment2"
                  name="discounted_price"
                  type="number"
                  value={discountPrice}
                  onChange={(e) => onChangeFormData(e, setDiscountPrice)}
                  InputProps={
                    ({
                      startAdornment: (
                        <InputAdornment position="start"></InputAdornment>
                      ),
                    },
                      { inputProps: { min: 0 } })
                  }
                  onKeyPress={(event) => {
                    handleKeyPress(event);
                  }}
                />
              </Grid>
              <Grid item xs={12}>
                <Grid container spacing={1}>
                  <Grid item xs={12}>
                    <Typography variant="subtitle1" align="left">
                      Images*
                    </Typography>
                  </Grid>
                  <Grid item xs={12}>
                    <div>
                      <ImageUploader handleImages={handleImages} img={images} />
                    </div>
                  </Grid>
                </Grid>
              </Grid>

              <Grid item xs={12}>
                <Grid container spacing={1}>
                  <Grid item xs={12}>
                    <Typography variant="subtitle1" align="left">
                      Videos
                    </Typography>
                  </Grid>
                  <Grid item xs={12}>
                    <div>
                      <VideoUploader
                        handleVideos={handleVideos}
                        video={videos}
                      />
                    </div>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item xs={12}>
                <Grid container spacing={1}>
                  <Grid item xs={12}>
                    <Typography variant="subtitle1" align="left">
                      Tags
                    </Typography>
                  </Grid>
                  <Grid item xs={12}>
                    <div>
                      <Select
                        id="tags"
                        multiple
                        fullWidth
                        name="tags"
                        value={tags}
                        onChange={(event) => {
                          onChangeFormData(event, setTags);
                        }}
                        input={<Input id="tags" />}
                        renderValue={(selected) => {
                          console.log(selected, "**** selected ****");
                          return (
                            <div>
                              {typeof selected !== "string" &&
                                selected &&
                                selected.length > 0 &&
                                selected.map((value) => (
                                  <Chip key={value} label={value} />
                                ))}
                            </div>
                          );
                        }}
                        MenuProps={MenuProps}
                      >
                        {tagNames.map((name) => (
                          <MenuItem key={name} value={name}>
                            {name}
                          </MenuItem>
                        ))}
                      </Select>
                    </div>
                  </Grid>

                  <Grid item xs={12}>
                    <Typography variant="subtitle1" align="left">
                      Materials
                    </Typography>
                  </Grid>
                  <Grid item xs={12}>
                    <div>
                      <Select
                        id="material"
                        multiple
                        fullWidth
                        name="material"
                        value={materials}
                        onChange={(event) => {
                          onChangeFormData(event, setMaterials);
                        }}
                        input={<Input id="material" />}
                        renderValue={(selected) => {
                          let materialArr = [];
                          selected &&
                            selected.map((s) => {
                              const data =
                                materialList &&
                                materialList.length > 0 &&
                                materialList.find(
                                  (c) => Number(c.id) === Number(s)
                                );
                              if (data && Object.keys(data).length > 0) {
                                materialArr.push(`${data.name}`);
                              }
                            });

                          return materialArr.join(", ");
                        }}
                        MenuProps={MenuProps}
                      >
                        {materialList &&
                          materialList.length > 0 &&
                          materialList.map((v) => (
                            <MenuItem key={v.id} value={v.id}>
                              {v.name}
                            </MenuItem>
                          ))}
                      </Select>
                    </div>
                  </Grid>

                  <Grid item xs={12}>
                    <Typography variant="subtitle1" align="left">
                      Colors*
                    </Typography>
                  </Grid>
                  <Grid item xs={12}>
                    <div>
                      <Select
                        id="colors"
                        multiple
                        fullWidth
                        name="colors"
                        value={colors}
                        onChange={(event) => {
                          onChangeFormData(event, setColors);
                        }}
                        input={<Input id="Colors" />}
                        renderValue={(selected) => {
                          let colorArr = [];
                          selected &&
                            selected.map((s) => {
                              const data =
                                colorList &&
                                colorList.length > 0 &&
                                colorList.find(
                                  (c) => Number(c.id) === Number(s)
                                );
                              if (data && Object.keys(data).length > 0) {
                                colorArr.push(`${data.name}`);
                              }
                            });

                          return colorArr.join(", ");
                        }}
                        MenuProps={MenuProps}
                      >
                        {colorList &&
                          colorList.length > 0 &&
                          colorList.map((v) => (
                            <MenuItem key={v.id} value={v.id}>
                              {v.image && (
                                <Avatar
                                  src={v.image}
                                  size="md"
                                  variant="rounded"
                                />
                              )}
                              <span style={{ marginLeft: "20px" }}>
                                {" "}
                                {v.name}
                              </span>
                            </MenuItem>
                          ))}
                      </Select>
                    </div>
                  </Grid>

                  <Grid item xs={12}>
                    <Typography variant="subtitle1" align="left">
                      Major Colors*
                    </Typography>
                  </Grid>
                  <Grid item xs={12}>
                    <div>
                      <Select
                        id="majorColors"
                        multiple
                        fullWidth
                        name="major_color"
                        value={majorColors}
                        onChange={(event) => {
                          onChangeFormData(event, setMajorColors);
                        }}
                        input={<Input id="majorColors" />}
                        renderValue={(selected) => {
                          let colorArr = [];
                          selected &&
                            selected.map((s) => {
                              const data =
                                colorList &&
                                colorList.length > 0 &&
                                colorList.find(
                                  (c) => Number(c.id) === Number(s)
                                );
                              if (data && Object.keys(data).length > 0) {
                                colorArr.push(`${data.name}`);
                              }
                            });

                          return colorArr.join(", ");
                        }}
                        MenuProps={MenuProps}
                      >
                        {colorList &&
                          colorList.length > 0 &&
                          colorList.map((v) => (
                            <MenuItem key={v.id} value={v.id}>
                              {v.image && (
                                <Avatar
                                  src={v.image}
                                  size="md"
                                  variant="rounded"
                                />
                              )}
                              <span style={{ marginLeft: "20px" }}>
                                {" "}
                                {v.name}
                              </span>
                            </MenuItem>
                          ))}
                      </Select>
                    </div>
                  </Grid>

                  <Grid item xs={12}>
                    <Typography variant="subtitle1" align="left">
                      Minor Colors*
                    </Typography>
                  </Grid>
                  <Grid item xs={12}>
                    <div>
                      <Select
                        id="minorColors"
                        multiple
                        fullWidth
                        name="minor_colors"
                        value={minorColors}
                        onChange={(event) => {
                          onChangeFormData(event, setMinorColors);
                        }}
                        input={<Input id="minorColors" />}
                        renderValue={(selected) => {
                          let colorArr = [];
                          selected &&
                            selected.map((s) => {
                              const data =
                                colorList &&
                                colorList.length > 0 &&
                                colorList.find(
                                  (c) => Number(c.id) === Number(s)
                                );
                              if (data && Object.keys(data).length > 0) {
                                colorArr.push(`${data.name}`);
                              }
                            });

                          return colorArr.join(", ");
                        }}
                        MenuProps={MenuProps}
                      >
                        {colorList &&
                          colorList.length > 0 &&
                          colorList.map((v) => (
                            <MenuItem key={v.id} value={v.id}>
                              {v.image && (
                                <Avatar
                                  src={v.image}
                                  size="md"
                                  variant="rounded"
                                />
                              )}
                              <span style={{ marginLeft: "20px" }}>
                                {" "}
                                {v.name}
                              </span>
                            </MenuItem>
                          ))}
                      </Select>
                    </div>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  id="standard-select-currency"
                  select
                  label="Availability*"
                  name="availability"
                  fullWidth
                  value={isAvailabilty}
                  onChange={(event) => onChangeFormData(event, setAvailability)}
                >
                  {availabilty &&
                    availabilty.length > 0 &&
                    availabilty.map((option) => (
                      <MenuItem key={option} value={option}>
                        {option}
                      </MenuItem>
                    ))}
                </TextField>
              </Grid>
              <Grid item xs={12}>
                <Typography variant="subtitle1" align="left">
                  Sections
                </Typography>
              </Grid>

              <Grid item md={6} xs={12}>
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={section.trending ? true : false}
                      name="trending"
                      onChange={(e) => onChangeFormData(e, setSection)}
                    />
                  }
                  label="Trending"
                />
              </Grid>

              <Grid item md={6} xs={12}>
                <FormControlLabel
                  control={
                    <Checkbox
                      name="latest"
                      checked={section.latest ? true : false}
                      onChange={(e) => onChangeFormData(e, setSection)}
                    />
                  }
                  label="Latest"
                />
              </Grid>

              <Grid item xs={12}>
                <Typography variant="subtitle1" align="left">
                  Suggestion*
                </Typography>
              </Grid>
              <Grid item xs={12}>
                <div>
                  <Select
                    id="suggestion"
                    multiple
                    fullWidth
                    value={suggestions}
                    name="suggestions"
                    onChange={(event) => {
                      onChangeFormData(event, setSuggestions);
                    }}
                    input={<Input id="suggestion" />}
                    renderValue={(selected) => {
                      let vehicleArr = [];
                      selected &&
                        selected.map((s) => {
                          const data =
                            vehicleList &&
                            vehicleList.length > 0 &&
                            vehicleList.find((v) => Number(v.id) === Number(s));
                          if (data && Object.keys(data).length > 0) {
                            vehicleArr.push(`${data.brand} ${data.model}`);
                          }
                        });

                      return vehicleArr.join(", ");
                    }}
                    MenuProps={MenuProps}
                  >
                    {vehicleList &&
                      vehicleList.length > 0 &&
                      vehicleList.map((v) => (
                        <MenuItem key={v.id} value={v.id}>
                          {v.brand} {v.model} {v.year}
                        </MenuItem>
                      ))}
                  </Select>
                </div>
              </Grid>

              {/* <Grid item xs={12}>
                <TextField
                  id="outlined-basic2"
                  fullWidth
                  multiline
                  rows={3}
                  value={productDescription}
                  label="Product Description"
                  onChange={(event) =>
                    setProductDescription(event.target.value)
                  }
                />
              </Grid> */}
              <Grid item xs={12}>
                <span className="richTitle">Additional Info*</span>
                <RichTextEditor
                  productInfo={additionalInfo}
                  name="additional_info"
                  onChangeEditor={onChangeFormData}
                />
                {/* <TextField
                  id="outlined-basic1"
                  fullWidth
                  multiline
                  rows={3}
                  name="additional_info"
                  label="Additional Info*"
                  value={additionalInfo}
                  maxRows={10}
                  minRows={3}
                  onChange={(event) =>
                    onChangeFormData(event, setAdditionalInfo)
                  }
                /> */}
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions>
            <AnimateButton>
              <LoadingButton
                size="medium"
                type="submit"
                disabled={
                  !category ||
                  !productName ||
                  !ratings ||
                  !images ||
                  images.length === 0 ||
                  !orignalPrice ||
                  !productDescription ||
                  !vehicleType ||
                  !majorColors ||
                  majorColors.length === 0 ||
                  !minorColors ||
                  minorColors.length === 0 ||
                  !brand ||
                  !productCode ||
                  !isAvailabilty ||
                  !colors ||
                  colors.length === 0 ||
                  !quantity ||
                  !suggestions ||
                  suggestions.length === 0 ||
                  !additionalInfo
                }
                onClick={() => handleCreateProduct()}
                loading={loading}
                loadingPosition="center"
                // startIcon={<SaveIcon />}
                variant="contained"
              >
                {productInfo.id ? "Update" : "Create"}
              </LoadingButton>
            </AnimateButton>
            <Button variant="text" color="error" onClick={handleCloseDialog}>
              Close
            </Button>
          </DialogActions>
        </>
      )}
    </Dialog>
  );
};

ProductAdd.propTypes = {
  open: PropTypes.bool,
  handleCloseDialog: PropTypes.func,
};

export default ProductAdd;

import React, { useState, memo } from "react";
import CloseIcon from "@mui/icons-material/Close";
import { s3 } from "../../../aws/aws-s3";
import { apiErrorHandler } from "../../../helpers";
import uploadIcon from "../../../../assets/images/e-commerce/uploadIcon.svg";
import CircularProgress from "@mui/material/CircularProgress";
import Box from "@mui/material/Box";

const ImageUploader = (props) => {
  const [file, setFile] = useState(!!props?.img?.length ? [...props.img] : []);
  const [imageLoader, setImageLoader] = useState(false);
  const onFileChange = async (e) => {
    const selectedFile = e.target.files[0];
    setImageLoader(true);
    s3?.uploadFile(selectedFile, selectedFile?.name)
      .then((data) => {
        if (data && data.location) {
          setFile([...file, data.location]);
          props.handleImages([...file, data.location]);
        }
        setImageLoader(false);
      })
      .catch((err) => {
        setImageLoader(false);

        apiErrorHandler(err, "Error while uploading images.");
      });
  };

  function deleteFile(e) {
    const images = file.filter((item, index) => index !== e);
    setFile(images);
    props.handleImages(images);
  }

  return (
    <form>
      <div className="form-group preview">
        {file.length > 0 &&
          file.map((item, index) => {
            return (
              <div key={item} className="upload-image coverimg">
                <div
                  className="close-icon"
                  style={{ cursor: "pointer" }}
                  onClick={() => {
                    deleteFile(index);
                  }}
                >
                  <CloseIcon />
                </div>
                <div className="category-image">
                  <img
                    style={{ maxHeight: "90px", maxWidth: "100%" }}
                    src={item}
                    alt="User Icon"
                  />
                </div>
              </div>
            );
          })}
      </div>

      <div className="category-upload-file-add" style={{ width: "100%" }}>
        <input
          type="file"
          accept="image/x-png, image/jpg, image/jpeg"
          onChange={onFileChange}
          name="sportImage"
        />
        <div className="upload-icon">
          {imageLoader ? (
            <Box sx={{ display: "flex" }}>
              <CircularProgress />
            </Box>
          ) : (
            <>
              <img src={uploadIcon} alt="Upload Icon" />
              <p>Upload Image</p>
            </>
          )}
        </div>
      </div>
    
    </form>
  );
};

export default memo(ImageUploader);

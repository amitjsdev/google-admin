import PropTypes from 'prop-types';
import * as React from 'react';
import API from "../../../../api/axios";
import { format } from "date-fns";

// material-ui
import { useTheme } from '@mui/material/styles';
import {
  Stack,
  Button,
  Box,
  CardContent,
  Checkbox,
  Grid,
  IconButton,
  InputAdornment,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
  TableSortLabel,
  TextField,
  Toolbar,
  Tooltip,
  Dialog,
  Typography
} from '@mui/material';
import { visuallyHidden } from '@mui/utils';

// project imports
import Chip from 'ui-component/extended/Chip';
import MainCard from 'ui-component/cards/MainCard';
import { useDispatch, useSelector } from 'store';
import { getOrders } from 'store/slices/customer';

// assets
import DeleteIcon from '@mui/icons-material/Delete';
import FilterListIcon from '@mui/icons-material/FilterListTwoTone';
import PrintIcon from '@mui/icons-material/PrintTwoTone';
import FileCopyIcon from '@mui/icons-material/FileCopyTwoTone';
import SearchIcon from '@mui/icons-material/Search';
import VisibilityTwoToneIcon from '@mui/icons-material/VisibilityTwoTone';
import EditTwoToneIcon from '@mui/icons-material/EditTwoTone';

// material-ui
// import { useTheme } from "@mui/material/styles";


import { LocalizationProvider } from "@mui/lab";
import AdapterDateFns from "@mui/lab/AdapterDateFns";

// table header options

const headCells = [
  {
    id: 'id',
    numeric: true,
    label: 'ID',
    align: 'left'
  },
  {
    id: 'name',
    numeric: false,
    label: 'Product',
    align: 'left'
  },
  {
    id: 'detail',
    numeric: false,
    label: 'Detail',
    align: 'left'
  },
  {
    id: 'Brand',
    numeric: true,
    label: 'Brand',
    align: 'left'
  },
  {
    id: 'Qty',
    numeric: true,
    label: 'Quantity',
    align: 'left'
  },
  {
    id: 'Price',
    numeric: true,
    label: 'Price',
    align: 'left'
  },
  {
    id: 'amount',
    numeric: true,
    label: 'Total Amount',
    align: 'left'
  },
  {
    id: 'date',
    numeric: true,
    label: 'Order Created',
    align: 'center'
  }
];

// ==============================|| TABLE HEADER ||============================== //

function EnhancedTableHead({ onSelectAllClick, order, orderBy, numSelected, rowCount, onRequestSort, theme, selected }) {
  const createSortHandler = (property) => (event) => {
    onRequestSort(event, property);
  };

  return (
    <TableHead>
      <TableRow>

        {numSelected > 0 && (
          <TableCell padding="none" colSpan={8}>
            <EnhancedTableToolbar numSelected={selected.length} />
          </TableCell>
        )}
        {numSelected <= 0 &&
          headCells.map((headCell) => (
            <TableCell
              key={headCell.id}
              align={headCell.align}
              padding={headCell.disablePadding ? 'none' : 'normal'}
              sortDirection={orderBy === headCell.id ? order : false}
            >
              {/* <TableSortLabel
                              active={orderBy === headCell.id}
                              direction={orderBy === headCell.id ? order : 'asc'}
                              onClick={createSortHandler(headCell.id)}
                          > */}
              {headCell.label}
              {orderBy === headCell.id ? (
                <Box component="span" sx={visuallyHidden}>
                  {order === 'desc' ? 'sorted descending' : 'sorted ascending'}
                </Box>
              ) : null}
              {/* </TableSortLabel> */}
            </TableCell>
          ))}
        {/* {numSelected <= 0 && (
          <TableCell sortDirection={false} align="center" sx={{ pr: 3 }}>
            <Typography variant="subtitle1" sx={{ color: theme.palette.mode === 'dark' ? 'grey.600' : 'grey.900' }}>
              Action
            </Typography>
          </TableCell>
        )} */}
      </TableRow>
    </TableHead>
  );
}
// ==============================|| TABLE HEADER TOOLBAR ||============================== //

const EnhancedTableToolbar = ({ numSelected }) => (
  <Toolbar
    sx={{
      p: 0,
      pl: 1,
      pr: 1,
      ...(numSelected > 0 && {
        color: (theme) => theme.palette.secondary.main
      })
    }}
  >
    {numSelected > 0 ? (
      <Typography color="inherit" variant="h4">
        {numSelected} Selected
      </Typography>
    ) : (
      <Typography variant="h6" id="tableTitle">
        Nutrition
      </Typography>
    )}
    <Box sx={{ flexGrow: 1 }} />
    {numSelected > 0 && (
      <Tooltip title="Delete">
        <IconButton size="large">
          <DeleteIcon fontSize="small" />
        </IconButton>
      </Tooltip>
    )}
  </Toolbar>
);

// ==============================|| CALENDAR EVENT ADD / EDIT / DELETE ||============================== //

const ViewOrder = ({
  viewOrderId, handleViewOrderClose
}) => {
  const theme = useTheme();
  const [order, setOrder] = React.useState('asc');
  const [orderBy, setOrderBy] = React.useState('calories');
  const [selected, setSelected] = React.useState([]);
  const [rows, setRows] = React.useState([]);
  const [viewOrderData, setViewOrderData] = React.useState([]);

  const handleOrderList = async (id) => {
    try {
      const response = await API.get(`/order/${id}`);
      if (response && response.data && response.data.data) {
        const orderListData = response.data.data?.order_products;
        setViewOrderData(orderListData);
      }
    } catch (error) {
      alert("Something went wrong while getting the Store List");
    }
  };

  React.useEffect(() => {
    if (viewOrderId) {
      handleOrderList(viewOrderId);
    }
  }, [viewOrderId]);

  return (
    <>



      <LocalizationProvider dateAdapter={AdapterDateFns}>
        {/* table */}
        <TableContainer>
          <Table sx={{ minWidth: 750 }} aria-labelledby="tableTitle">
            <EnhancedTableHead
              numSelected={selected.length}
              order={order}
              orderBy={orderBy}
              rowCount={rows.length}
              theme={theme}
            />
            {console.log('viewOrderData', viewOrderData)}
            <TableBody>
              {viewOrderData && viewOrderData.length > 0 && viewOrderData.map((row, index) => {
                /** Make sure no display bugs if row isn't an OrderData object */
                if (typeof row === 'number') return null;


                const labelId = `enhanced-table-checkbox-${index}`;

                return (
                  <TableRow
                    hover
                    role="checkbox"
                    tabIndex={-1}
                    key={index}
                  >

                    <TableCell
                      component="th"
                      scope="row"

                    >
                      <Typography
                        variant="subtitle1"
                        sx={{ color: theme.palette.mode === 'dark' ? 'grey.600' : 'grey.900' }}
                      >
                        {' '}
                        #{row.product_id}{' '}
                      </Typography>
                    </TableCell>
                    <TableCell
                      component="th"
                      id={labelId}
                      scope="row"
                    >
                      <Typography
                        variant="subtitle1"
                        sx={{ color: theme.palette.mode === 'dark' ? 'grey.600' : 'grey.900' }}
                      >
                        {' '}
                        {row?.product?.name}
                      </Typography>
                    </TableCell>
                    <TableCell>{row?.product?.detail}</TableCell>

                    <TableCell>{row?.product?.brand}</TableCell>
                    <TableCell >{row?.quantity}</TableCell>
                    <TableCell >{row?.amount_per_product}</TableCell>
                    <TableCell >
                      <Typography
                        variant="subtitle1"
                        sx={{ color: theme.palette.mode === 'dark' ? 'grey.600' : 'grey.900' }}
                      >
                        {' '}
                        {row?.total_amount}
                      </Typography>
                    </TableCell>
                    <TableCell align="center"> {format(new Date(row?.createdAt), "E, MMM d yyyy")}</TableCell>
                    {/* <TableCell align="center">
                      <Chip label={row?.status} size="small" chipcolor="primary" />
                    </TableCell> */}
                    {/* <TableCell align="center" sx={{ pr: 3 }}>
                      <IconButton color="primary" size="large">
                        <VisibilityTwoToneIcon sx={{ fontSize: '1.3rem' }} />
                      </IconButton>
                      <IconButton color="secondary" size="large">
                                            <EditTwoToneIcon sx={{ fontSize: '1.3rem' }} />
                                        </IconButton>
                    </TableCell> */}
                  </TableRow>
                );
              })}

            </TableBody>
          </Table>

        </TableContainer>

      </LocalizationProvider>
      <Grid item>
        <Stack className="closeBtn" direction="row" spacing={2} alignItems="center">
          <Button
            style={{ marginTop: '10px', marginLeft: "90%", marginBottom: "13px" }}
            className="closeBtn"
            type="button"
            variant="outlined"
            onClick={handleViewOrderClose}
          >
            Close
          </Button>

        </Stack>
      </Grid>
    </>
  );
};


export default ViewOrder;

import axios from "axios";
import appConfig from "../AppConfig";

const customAxios = axios.create({
  baseURL: `${appConfig.REACT_APP_API_BASE_URL}/api/v1/`,
  timeout: 10000,
  headers: {
    "Content-Type": "application/json",
  },
});

const requestHandler = (request) => {
  const token = '';
  if (token) {
    request.headers.Authorization = `Bearer ${token || ""}`;
  }

  return request;
};



const responseHandler = (response) => {
  // eslint-disable-next-line no-empty
  if (response.status === 401) {
  }

  return response;
};

const errorHandler = (error) => {
  return Promise.reject(error);
};

// Step-3: Configure/make use of request & response interceptors from Axios
// Note: You can create one method say configureInterceptors, add below in that,
// export and call it in an init function of the application/page.
customAxios.interceptors.request.use(
  (request) => requestHandler(request),
  (error) => errorHandler(error)
);

customAxios.interceptors.response.use(
  (response) => responseHandler(response),
  (error) => errorHandler(error)
);

// Step-4: Export the newly created Axios instance to be used in different locations.
export default customAxios;

// third-party
import { FormattedMessage } from "react-intl";

// assets
import {
  IconUserCheck,
  IconBasket,
  IconMessages,
  IconLayoutKanban,
  IconMail,
  IconCalendar,
  IconNfc,
} from "@tabler/icons";

// constant
const icons = {
  IconUserCheck,
  IconBasket,
  IconMessages,
  IconLayoutKanban,
  IconMail,
  IconCalendar,
  IconNfc,
};

// ==============================|| APPLICATION MENU ITEMS ||============================== //

const application = {
  id: "application",
  title: <FormattedMessage id="application" />,
  type: "group",

  children: [

    {
      id: "Categories",
      title: <FormattedMessage id="Categories" />,
      type: "item",
      url: "/category",
      breadcrumbs: false,
    },

    {
      id: "Vehicle Data",
      title: <FormattedMessage id="Vehicle Details" />,
      type: "item",
      url: "/vehicles",
      breadcrumbs: false,
    },
    {
      id: "Products",
      title: <FormattedMessage id="Products" />,
      type: "item",
      url: "/products",
      breadcrumbs: false,
    },
    {
      id: "Stores",
      title: <FormattedMessage id="Stores" />,
      type: "item",
      url: "/stores",
      breadcrumbs: false,
    },
    {
      id: "Orders",
      title: <FormattedMessage id="Orders" />,
      type: "item",
      url: "/orders",
      breadcrumbs: false,
    },
  ],
};

export default application;
